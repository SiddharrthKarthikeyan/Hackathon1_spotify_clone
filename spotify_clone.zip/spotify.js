/*var request = require("request");
var user_id = "sidkay";
var token = "BQAk608SGFXf6VhdTjpZJRCwgG4KWr0ZsDsYjvc2m3pYVxzNIp8x-7x4kmGREqwvqU8BaoHMmTbWg7Hdd96F2sevGvpWDQuQy69U_JfYZwZwhLgpQ3SP093c1V-SbRiLt55j1KB-LDYXHdEZVJuRBO5YBSdB_GoJaP-ngzqjTl9QmbG3";
var user_playlist_url = "https://api.spotify.com/v1/users/"+user_id+"/playlists";

request({url:user_playlist_url, headers:{"Authorization":token}}, function(err,res){
    if(res){
        var playlists = json.parse(res.body);
        var user_playlist_url = playlists.items[0].href;
        request({url:user_playlist_url, headers:{"Authorization":token}}, function(err,res){
            if(res){
                var playlists = json.parse(res.body);
                console.log("playlist: " + playlist.name);
                playlist.tracks.forEach(function(track){
                     console.log(track.track.name);    
                })
            }
        })
    }
})*/

//var request = new XMLHttpRequest();
var clientId = '07a636a76a4548aebadf93c487f70933';
var clientSecret = 'cc429184ccd9492da16130223c6364f9';
function getToken() {
const myRequest = new Request('https://accounts.spotify.com/api/token', {
    method: 'POST',
    headers : {
        'Content-Type' : 'application/x-www-form-urlencoded',
        'Authorization' : 'Basic' +  btoa(clientId + ':' + clientSecret)

    },
    body : 'grant_type=client_credentials', 
    //mode: 'no-cors',
    cache: 'default',
  });
  
  fetch(myRequest)
  .then(response => response.json())
  .then(result => {
    console.log('Success:', result);
  })
  .catch(error => {
    //console.error('Error:', error);
  });
}
function getPlayLists(){
  const myRequest1 = ('https://api.spotify.com/v1/me/playlists', {
    method: 'GET',
    mode: 'no-cors',
    cache: 'default',
  });
  
  fetch('https://api.spotify.com/v1/me/playlists' , {
    method: 'GET',
    mode: 'no-cors',
    cache: 'default', 
    headers : {'Authorization' : 'Bearer'}
    

  })  
  .then(response => response.json())
  .then(result => {
    console.log('Success:', result);
  })
  .catch((error) => {
    //console.error('Error:', error);
  });


}






  

/*request.open('GET','https://api.spotify.com/v1/users/{user_id}/playlists',true);
request.send();
request.onload = function(){
    var user_id = "sidkay";
    var token = "BQAk608SGFXf6VhdTjpZJRCwgG4KWr0ZsDsYjvc2m3pYVxzNIp8x-7x4kmGREqwvqU8BaoHMmTbWg7Hdd96F2sevGvpWDQuQy69U_JfYZwZwhLgpQ3SP093c1V-SbRiLt55j1KB-LDYXHdEZVJuRBO5YBSdB_GoJaP-ngzqjTl9QmbG3";
    var user_playlists = JSON.parse(this.response);
    request({url:user_playlists,headers:{"Authorization":token}}, function(err,res){
        if(res){
            
            var playlists = user_playlists.items[0].href;
            request({url:user_playlist_url, headers:{"Authorization":token}}, function(err,res){
                if(res){
                    var user_playlists = JSON.parse(this.response);
                    console.log("playlist: " + playlist.name);
                    playlist.tracks.forEach(function(track){
                    console.log(track.track.name);    
                })
            }
        })
    }
})

}*/